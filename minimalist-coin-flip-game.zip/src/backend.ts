import { STORE } from "./config";

type RentryBody = {
  status: string;
  content: unknown;
};

type ScoreStore = {
  v: number;
  highScore: number;
};

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function rentry(
  path: string,
  fields: Record<string, string>,
  attempt = 0
): Promise<RentryBody> {
  const res = await fetch(`${STORE.base}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(fields),
  });
  const data = (await res.json()) as RentryBody;
  if (data.status === "429" && attempt < 4) {
    await sleep(400 * (attempt + 1));
    return rentry(path, fields, attempt + 1);
  }
  return data;
}

function parseHighScore(text: string): number {
  try {
    const parsed = JSON.parse(text) as {
      v?: number;
      highScore?: number;
      players?: Record<string, { highScore?: number }>;
    };
    if (typeof parsed?.highScore === "number") {
      return Math.max(0, Math.floor(parsed.highScore));
    }
    if (parsed?.players && typeof parsed.players === "object") {
      return Object.values(parsed.players).reduce((best, p) => {
        const n = Math.floor(p?.highScore || 0);
        return n > best ? n : best;
      }, 0);
    }
  } catch {
    /* empty / invalid */
  }
  return 0;
}

async function fetchStore(): Promise<ScoreStore> {
  const data = await rentry(`/fetch/${STORE.page}`, {
    edit_code: STORE.editCode,
  });
  if (data.status !== "200" || !data.content || typeof data.content !== "object") {
    throw new Error("store unavailable");
  }
  const content = data.content as { text?: string };
  return { v: 2, highScore: parseHighScore(content.text || "") };
}

async function saveHighScore(highScore: number): Promise<void> {
  const data = await rentry(`/edit/${STORE.page}`, {
    edit_code: STORE.editCode,
    text: JSON.stringify({ v: 2, highScore: Math.max(0, Math.floor(highScore)) }),
    update_mode: "replace",
  });
  if (data.status !== "200") {
    throw new Error("save failed");
  }
}

let writeChain: Promise<void> = Promise.resolve();

function enqueue<T>(job: () => Promise<T>): Promise<T> {
  const run = writeChain.then(job, job);
  writeChain = run.then(
    () => undefined,
    () => undefined
  );
  return run;
}

export async function loadGlobalHighScore(): Promise<number> {
  const store = await fetchStore();
  return store.highScore;
}

/** Push a new record only if it beats the stored global number. */
export function submitGlobalHighScore(score: number): Promise<number> {
  const next = Math.max(0, Math.floor(score));
  return enqueue(async () => {
    const store = await fetchStore();
    if (next > store.highScore) {
      await saveHighScore(next);
      return next;
    }
    return store.highScore;
  });
}
