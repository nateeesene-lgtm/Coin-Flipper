/** Each loan gets a fresh 10-minute repayment window. */
export const LOAN_MS = 10 * 60 * 1000;

/** Borrow buttons. Hidden when above the current max loan. */
export const LOAN_PRESETS = [1, 5, 10, 25, 50];

/**
 * Maximum bank loan by this run's highest balance.
 * Tune this table to change lending limits later.
 *
 *   Highest $10    → max $20
 *   Highest $100   → max $50
 *   Highest $1,000 → max $200
 */
export const LOAN_TIERS: { minHighScore: number; maxLoan: number }[] = [
  { minHighScore: 0, maxLoan: 10 },
  { minHighScore: 10, maxLoan: 20 },
  { minHighScore: 100, maxLoan: 50 },
  { minHighScore: 1000, maxLoan: 200 },
  { minHighScore: 5000, maxLoan: 500 },
  { minHighScore: 10000, maxLoan: 1000 },
  { minHighScore: 50000, maxLoan: 2500 },
];

export function getMaxBankLoan(highestScore: number): number {
  let max = LOAN_TIERS[0]?.maxLoan ?? 10;
  for (const tier of LOAN_TIERS) {
    if (highestScore >= tier.minHighScore) max = tier.maxLoan;
  }
  return max;
}

export function formatMoney(n: number): string {
  return "$" + Math.max(0, Math.floor(n)).toLocaleString("en-US");
}

/** Anonymous global high-score store (rentry.co). Number only — no names. */
export const STORE = {
  base: "https://rentry.co/api",
  page: "coinflip-arena-lb",
  editCode: "flip-arena-2026",
};

export const RUN_KEY = "coinflip-run-v4";

/** Each savings deposit matures after 5 minutes. */
export const SAVINGS_MS = 5 * 60 * 1000;

/** Minimum savings deposit. $1 yields no profit after the bank fee. */
export const SAVE_MIN = 2;

/** Doubled, then the bank takes half the profit. $10 → $20 − $5 fee = $15. */
export function maturedReturn(principal: number): number {
  const profit = principal;
  const fee = Math.floor(profit / 2);
  return principal + profit - fee;
}

export const EXTREME_FROM = 1_000_000;
export const FINAL_AMOUNT = 1_000_000_000;

export type Milestone = {
  amount: number;
  name: string;
};

export const MILESTONES: Milestone[] = [
  { amount: 50, name: "Barely Scratching the Surface" },
  { amount: 100, name: "Getting Somewhere" },
  { amount: 200, name: "Making Progress" },
  { amount: 400, name: "Starting to Stack Up" },
  { amount: 800, name: "Money Machine" },
  { amount: 1600, name: "Cash Collector" },
  { amount: 3200, name: "Bank Material" },
  { amount: 6400, name: "Rolling in It" },
  { amount: 12800, name: "Big Spender" },
  { amount: 25600, name: "High Roller" },
  { amount: 51200, name: "Money Talks" },
  { amount: 102400, name: "Your Own Bank" },
  { amount: 204800, name: "This Is Getting Stupid" },
  { amount: 409600, name: "Richer Than You Need to Be" },
  { amount: 819200, name: "What Are You Doing?" },
  { amount: 1_000_000, name: "How Did We Get Here?" },
  { amount: 2_000_000, name: "You're Still Going?" },
  { amount: 4_000_000, name: "Seriously?" },
  { amount: 8_000_000, name: "Touch Grass" },
  { amount: 16_000_000, name: "The Bank Knows You" },
  { amount: 32_000_000, name: "Money Mountain" },
  { amount: 64_000_000, name: "Beyond Rich" },
  { amount: 128_000_000, name: "This Shouldn't Be Possible" },
  { amount: 256_000_000, name: "You've Gone Too Far" },
  { amount: 512_000_000, name: "There Is No Turning Back" },
  { amount: 1_000_000_000, name: "You Really Beat the Game Huh?" },
];

export function currentMilestone(unlocked: number[]): Milestone | null {
  let found: Milestone | null = null;
  for (const m of MILESTONES) {
    if (unlocked.includes(m.amount)) found = m;
  }
  return found;
}

export function nextMilestone(unlocked: number[]): Milestone | null {
  for (const m of MILESTONES) {
    if (!unlocked.includes(m.amount)) return m;
  }
  return null;
}
