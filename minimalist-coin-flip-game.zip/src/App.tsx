import { useEffect, useRef, useState } from "react";
import {
  currentMilestone,
  EXTREME_FROM,
  FINAL_AMOUNT,
  formatMoney,
  getMaxBankLoan,
  LOAN_MS,
  LOAN_PRESETS,
  maturedReturn,
  MILESTONES,
  nextMilestone,
  RUN_KEY,
  SAVE_MIN,
  SAVINGS_MS,
  type Milestone,
} from "./config";
import { loadGlobalHighScore, submitGlobalHighScore } from "./backend";

type Side = "HEADS" | "TAILS";
type Phase = "ready" | "pick" | "spin" | "result" | "broke" | "dead";

type Deposit = {
  id: string;
  principal: number;
  readyAt: number;
  remaining: number | null;
};

type RunState = {
  balance: number;
  debt: number;
  debtExpiresAt: number | null;
  best: number;
  savingsUnlocked: boolean;
  unlocked: number[];
  finalSeen: boolean;
  deposits: Deposit[];
};

let audioCtx: AudioContext | null = null;

function getAudio(): AudioContext | null {
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  if (!AC) return null;
  if (!audioCtx) audioCtx = new AC();
  if (audioCtx.state === "suspended") void audioCtx.resume();
  return audioCtx;
}

function tone(
  ctx: AudioContext,
  freq: number,
  start: number,
  dur: number,
  type: OscillatorType,
  vol: number,
  endFreq?: number
) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, start);
  if (endFreq) osc.frequency.exponentialRampToValueAtTime(endFreq, start + dur);
  gain.gain.setValueAtTime(vol, start);
  gain.gain.exponentialRampToValueAtTime(0.001, start + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(start);
  osc.stop(start + dur + 0.02);
}

function playFlipSound() {
  const ctx = getAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  tone(ctx, 920, t, 0.09, "triangle", 0.07, 420);
  tone(ctx, 1400, t + 0.04, 0.1, "sine", 0.04, 500);
  tone(ctx, 240, t + 0.08, 0.12, "square", 0.02, 120);
}

function playLandSound() {
  const ctx = getAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  tone(ctx, 520, t, 0.08, "sine", 0.06, 280);
  tone(ctx, 880, t + 0.02, 0.1, "triangle", 0.035, 440);
}

function playWinSound() {
  const ctx = getAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  tone(ctx, 523, t, 0.12, "sine", 0.05, 523);
  tone(ctx, 659, t + 0.1, 0.14, "sine", 0.05, 659);
}

function playLoseSound() {
  const ctx = getAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  tone(ctx, 220, t, 0.18, "sine", 0.05, 110);
}

function playAchieveSound() {
  const ctx = getAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  tone(ctx, 523, t, 0.14, "sine", 0.06);
  tone(ctx, 659, t + 0.12, 0.14, "sine", 0.06);
  tone(ctx, 784, t + 0.24, 0.22, "sine", 0.07);
}

function playFinalSound() {
  const ctx = getAudio();
  if (!ctx) return;
  const t = ctx.currentTime;
  tone(ctx, 196, t, 0.5, "sine", 0.07, 98);
  tone(ctx, 392, t + 0.35, 0.55, "sine", 0.06, 196);
  tone(ctx, 523, t + 0.7, 0.7, "triangle", 0.05, 262);
  tone(ctx, 784, t + 1.15, 1.1, "sine", 0.07, 392);
}

function formatTime(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function nextRotation(current: number, side: Side) {
  const full = 360;
  const spins = 6;
  const target = side === "HEADS" ? 0 : 180;
  const normalized = ((current % full) + full) % full;
  let delta = (target - normalized + full) % full;
  delta += spins * full;
  return current + delta;
}

function newId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function settleDeposits(list: Deposit[], t: number): Deposit[] {
  return list.map((d) => {
    if (t >= d.readyAt && d.remaining === null) {
      return { ...d, remaining: maturedReturn(d.principal) };
    }
    return d;
  });
}

function availableOf(list: Deposit[], t: number) {
  return settleDeposits(list, t).reduce((sum, d) => {
    if (t < d.readyAt) return sum;
    return sum + (d.remaining ?? maturedReturn(d.principal));
  }, 0);
}

function Coin({
  rotation,
  flipping,
}: {
  rotation: number;
  flipping: boolean;
}) {
  return (
    <div className={`coin-scene${flipping ? " tossing" : ""}`}>
      <div className="coin" style={{ transform: `rotateY(${rotation}deg)` }}>
        <div className="coin-face heads">
          <div className="ring" />
          <span className="label">HEADS</span>
        </div>
        <div className="coin-face tails">
          <div className="ring" />
          <span className="label">TAILS</span>
        </div>
      </div>
    </div>
  );
}

function emptyRun(): RunState {
  return {
    balance: 1,
    debt: 0,
    debtExpiresAt: null,
    best: 1,
    savingsUnlocked: false,
    unlocked: [],
    finalSeen: false,
    deposits: [],
  };
}

function mergeUnlocked(stored: number[] | undefined, best: number): number[] {
  const have = new Set(stored ?? []);
  for (const m of MILESTONES) {
    if (best >= m.amount) have.add(m.amount);
  }
  return MILESTONES.map((m) => m.amount).filter((n) => have.has(n));
}

function loadRun(): RunState {
  try {
    const raw = localStorage.getItem(RUN_KEY);
    if (!raw) return emptyRun();
    const p = JSON.parse(raw) as Partial<RunState> & {
      achievementUnlocked?: boolean;
    };
    const best = Math.max(1, Math.floor(p.best ?? 1));
    const unlocked = mergeUnlocked(
      Array.isArray(p.unlocked)
        ? p.unlocked
        : p.achievementUnlocked || best >= 50
          ? [50]
          : [],
      best
    );
    return {
      balance: Math.max(0, Math.floor(p.balance ?? 1)),
      debt: Math.max(0, Math.floor(p.debt ?? 0)),
      debtExpiresAt:
        typeof p.debtExpiresAt === "number" ? p.debtExpiresAt : null,
      best,
      savingsUnlocked: Boolean(p.savingsUnlocked) || unlocked.includes(50),
      unlocked,
      finalSeen: Boolean(p.finalSeen),
      deposits: Array.isArray(p.deposits) ? p.deposits : [],
    };
  } catch {
    return emptyRun();
  }
}

function saveRun(run: RunState) {
  localStorage.setItem(RUN_KEY, JSON.stringify(run));
}

export default function App() {
  const initial = loadRun();
  const expiredOnLoad =
    initial.debt > 0 &&
    initial.debtExpiresAt !== null &&
    Date.now() >= initial.debtExpiresAt;

  const startBalance = expiredOnLoad ? 1 : initial.balance;
  const startDebt = expiredOnLoad ? 0 : initial.debt;
  const startExpires = expiredOnLoad ? null : initial.debtExpiresAt;

  const [balance, setBalance] = useState(startBalance);
  const [wager, setWager] = useState(startBalance > 0 ? startBalance : 0);
  const [debt, setDebt] = useState(startDebt);
  const [debtExpiresAt, setDebtExpiresAt] = useState<number | null>(startExpires);
  const [best, setBest] = useState(initial.best);
  const [globalHigh, setGlobalHigh] = useState(initial.best);
  const [savingsUnlocked, setSavingsUnlocked] = useState(initial.savingsUnlocked);
  const [unlocked, setUnlocked] = useState<number[]>(initial.unlocked);
  const [finalSeen, setFinalSeen] = useState(initial.finalSeen);
  const [deposits, setDeposits] = useState<Deposit[]>(initial.deposits);
  const [toast, setToast] = useState<Milestone | null>(null);
  const [showEnding, setShowEnding] = useState(false);
  const [showSavings, setShowSavings] = useState(false);
  const [showMilestones, setShowMilestones] = useState(false);
  const [brokeBank, setBrokeBank] = useState(false);
  const [withdrawAmt, setWithdrawAmt] = useState(1);
  const [depositInput, setDepositInput] = useState("2");
  const [phase, setPhase] = useState<Phase>(
    expiredOnLoad ? "dead" : startBalance <= 0 ? "broke" : "ready"
  );
  const [outcome, setOutcome] = useState<Side>("HEADS");
  const [rotation, setRotation] = useState(0);
  const [flipping, setFlipping] = useState(false);
  const [won, setWon] = useState(false);
  const [delta, setDelta] = useState(0);
  const [fromAmt, setFromAmt] = useState(1);
  const [toAmt, setToAmt] = useState(1);
  const [repaid, setRepaid] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [balanceKey, setBalanceKey] = useState(0);

  const spinTimer = useRef<number | null>(null);
  const toastTimer = useRef<number | null>(null);
  const runRef = useRef<RunState>({
    balance: startBalance,
    debt: startDebt,
    debtExpiresAt: startExpires,
    best: initial.best,
    savingsUnlocked: initial.savingsUnlocked,
    unlocked: initial.unlocked,
    finalSeen: initial.finalSeen,
    deposits: initial.deposits,
  });

  function persist(next: RunState) {
    runRef.current = next;
    saveRun(next);
    if (next.best > globalHigh) {
      setGlobalHigh(next.best);
      void submitGlobalHighScore(next.best).then((n) => setGlobalHigh(n));
    }
  }

  function snapshot(patch: Partial<RunState>): RunState {
    return { ...runRef.current, ...patch };
  }

  function maybeUnlock(nextBal: number, nextBest: number, base: RunState) {
    const peak = Math.max(nextBal, nextBest);
    const have = new Set(base.unlocked);
    const newly = MILESTONES.filter(
      (m) => peak >= m.amount && !have.has(m.amount)
    );
    if (newly.length === 0) {
      return { ...base, best: nextBest };
    }
    const nextUnlocked = [...base.unlocked, ...newly.map((m) => m.amount)];
    const last = newly[newly.length - 1];
    const savings = base.savingsUnlocked || peak >= 50;
    const hitFinal = last.amount >= FINAL_AMOUNT && !base.finalSeen;
    setUnlocked(nextUnlocked);
    setSavingsUnlocked(savings);
    if (hitFinal) {
      setFinalSeen(true);
      setShowEnding(true);
      playFinalSound();
    } else {
      setToast(last);
      playAchieveSound();
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      toastTimer.current = window.setTimeout(() => setToast(null), 3800);
    }
    return {
      ...base,
      best: nextBest,
      unlocked: nextUnlocked,
      savingsUnlocked: savings,
      finalSeen: hitFinal || base.finalSeen,
    };
  }

  useEffect(() => {
    if (expiredOnLoad) {
      persist(
        snapshot({
          balance: 1,
          debt: 0,
          debtExpiresAt: null,
          deposits: [],
        })
      );
    }
    void loadGlobalHighScore()
      .then((n) => {
        setGlobalHigh(Math.max(n, runRef.current.best));
        if (runRef.current.best > n) {
          void submitGlobalHighScore(runRef.current.best).then(setGlobalHigh);
        }
      })
      .catch(() => {});

    const tick = window.setInterval(() => {
      const t = Date.now();
      setNow(t);
      const run = runRef.current;
      const settled = settleDeposits(run.deposits, t);
      if (JSON.stringify(settled) !== JSON.stringify(run.deposits)) {
        setDeposits(settled);
        persist({ ...run, deposits: settled });
      }
      if (
        run.debt > 0 &&
        run.debtExpiresAt !== null &&
        t >= run.debtExpiresAt
      ) {
        setPhase("dead");
      }
    }, 200);

    const poll = window.setInterval(() => {
      void loadGlobalHighScore()
        .then((n) => setGlobalHigh((g) => Math.max(g, n)))
        .catch(() => {});
    }, 8000);

    return () => {
      window.clearInterval(tick);
      window.clearInterval(poll);
      if (spinTimer.current) window.clearTimeout(spinTimer.current);
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const settled = settleDeposits(deposits, now);
  const available = availableOf(settled, now);
  const hasLocked = settled.some((d) => now < d.readyAt);
  const timeLeft = debtExpiresAt !== null ? debtExpiresAt - now : 0;
  const maxLoan = getMaxBankLoan(best);
  const menuOpen = showSavings || showMilestones;
  const showWager = phase === "ready" && balance > 0 && !menuOpen;
  const showFlip = phase === "ready" && !menuOpen;
  const showSide =
    !menuOpen &&
    (phase === "result" || phase === "ready" || phase === "broke");
  const current = currentMilestone(unlocked);
  const upcoming = nextMilestone(unlocked);

  function clampWager(next: number, max = balance) {
    if (max <= 0) return 0;
    return Math.min(max, Math.max(1, next));
  }

  function goBroke() {
    setShowSavings(false);
    setShowMilestones(false);
    setBrokeBank(availableOf(runRef.current.deposits, Date.now()) <= 0);
    setPhase("broke");
  }

  function handleFlip() {
    if (phase === "spin" || phase === "dead") return;
    if (balance <= 0) {
      goBroke();
      return;
    }
    setRepaid(false);
    setShowSavings(false);
    setShowMilestones(false);
    setPhase("pick");
  }

  function pick(side: Side) {
    if (phase !== "pick" || balance <= 0 || wager <= 0) return;

    const land: Side = Math.random() < 0.5 ? "HEADS" : "TAILS";
    const bet = clampWager(wager);
    setOutcome(land);
    setFlipping(true);
    setPhase("spin");
    setRotation((r) => nextRotation(r, land));
    playFlipSound();

    spinTimer.current = window.setTimeout(() => {
      setFlipping(false);
      playLandSound();

      const win = side === land;
      let nextBal = win ? balance + bet : balance - bet;
      let nextDebt = debt;
      let nextExpires = debtExpiresAt;
      let justRepaid = false;
      const peak = Math.max(balance, nextBal);

      if (win && nextDebt > 0 && nextBal >= nextDebt) {
        nextBal -= nextDebt;
        nextDebt = 0;
        nextExpires = null;
        justRepaid = true;
      }

      const nextBest = Math.max(best, Math.floor(peak));
      const next = maybeUnlock(nextBal, nextBest, {
        ...runRef.current,
        balance: nextBal,
        debt: nextDebt,
        debtExpiresAt: nextExpires,
      });

      setWon(win);
      setDelta(win ? bet : -bet);
      setFromAmt(balance);
      setToAmt(win ? balance + bet : balance - bet);
      setBalance(nextBal);
      setDebt(nextDebt);
      setDebtExpiresAt(nextExpires);
      setBest(nextBest);
      setRepaid(justRepaid);
      setWager(nextBal > 0 ? nextBal : 0);
      setBalanceKey((k) => k + 1);
      setPhase("result");
      persist(next);
      if (win) playWinSound();
      else playLoseSound();
    }, 1200);
  }

  function takeLoan(amount: number) {
    if (balance > 0) return;
    const amt = Math.floor(amount);
    if (amt < 1 || amt > maxLoan) return;
    const expires = Date.now() + LOAN_MS;
    const nextDebt = debt + amt;
    const nextBest = Math.max(best, amt);
    const next = maybeUnlock(amt, nextBest, {
      ...runRef.current,
      balance: amt,
      debt: nextDebt,
      debtExpiresAt: expires,
    });
    setBalance(amt);
    setWager(amt);
    setDebt(nextDebt);
    setDebtExpiresAt(expires);
    setBest(nextBest);
    setRepaid(false);
    setBrokeBank(false);
    setShowSavings(false);
    setPhase("ready");
    setNow(Date.now());
    setBalanceKey((k) => k + 1);
    persist(next);
  }

  function depositSavings(amount: number) {
    const amt = Math.floor(amount);
    if (!savingsUnlocked || amt < SAVE_MIN || amt > balance) return;
    const nextBal = balance - amt;
    const nextDeposits: Deposit[] = [
      ...settleDeposits(deposits, Date.now()),
      { id: newId(), principal: amt, readyAt: Date.now() + SAVINGS_MS, remaining: null },
    ];
    setBalance(nextBal);
    setDeposits(nextDeposits);
    setWager(nextBal > 0 ? Math.min(wager, nextBal) : 0);
    setDepositInput(nextBal >= SAVE_MIN ? String(Math.min(amt, nextBal)) : "");
    setBalanceKey((k) => k + 1);
    persist(
      snapshot({
        balance: nextBal,
        deposits: nextDeposits,
      })
    );
  }

  function withdrawSavings(amount: number) {
    const want = Math.floor(amount);
    const t = Date.now();
    let left = Math.min(want, availableOf(deposits, t));
    if (left < 1) return;
    const nextList: Deposit[] = [];
    for (const d of settleDeposits(deposits, t)) {
      if (t < d.readyAt) {
        nextList.push(d);
        continue;
      }
      const val = d.remaining ?? maturedReturn(d.principal);
      if (left <= 0) {
        nextList.push({ ...d, remaining: val });
        continue;
      }
      if (val <= left) {
        left -= val;
        continue;
      }
      nextList.push({ ...d, remaining: val - left });
      left = 0;
    }
    const gained = want - left;
    const nextBal = balance + gained;
    const nextBest = Math.max(best, nextBal);
    const next = maybeUnlock(nextBal, nextBest, {
      ...runRef.current,
      balance: nextBal,
      deposits: nextList,
    });
    setBalance(nextBal);
    setDeposits(nextList);
    setBest(nextBest);
    setWager(nextBal);
    setWithdrawAmt(1);
    setBalanceKey((k) => k + 1);
    persist(next);
    if (nextBal > 0 && phase === "broke") {
      setBrokeBank(false);
      setShowSavings(false);
      setPhase("ready");
    }
  }

  function again() {
    setRepaid(false);
    if (balance <= 0) goBroke();
    else setPhase("ready");
  }

  function restart() {
    const next: RunState = {
      balance: 1,
      debt: 0,
      debtExpiresAt: null,
      best,
      savingsUnlocked,
      unlocked,
      finalSeen,
      deposits: [],
    };
    setBalance(1);
    setWager(1);
    setDebt(0);
    setDebtExpiresAt(null);
    setDeposits([]);
    setShowSavings(false);
    setShowMilestones(false);
    setBrokeBank(false);
    setPhase("ready");
    setOutcome("HEADS");
    setRotation(0);
    setFlipping(false);
    setWon(false);
    setDelta(0);
    setFromAmt(1);
    setToAmt(1);
    setRepaid(false);
    setBalanceKey((k) => k + 1);
    persist(next);
  }

  if (phase === "dead") {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center px-6 text-center">
        <p className="text-lg font-extrabold tracking-wide">
          🏆 HIGHEST SCORE: {formatMoney(globalHigh)}
        </p>
        <h1 className="mt-10 text-3xl font-extrabold tracking-wide sm:text-4xl">
          BANK LOAN DEFAULTED
        </h1>
        <p className="mt-4 text-lg text-neutral-600">Your run has ended.</p>
        <button className="btn btn-flip mt-12" onClick={restart}>
          RESTART
        </button>
      </div>
    );
  }

  const presets = LOAN_PRESETS.filter((n) => n <= maxLoan);
  const depositAmt = Math.floor(Number(depositInput) || 0);
  const canDeposit =
    savingsUnlocked &&
    balance >= SAVE_MIN &&
    depositAmt >= SAVE_MIN &&
    depositAmt <= balance;
  const maxWithdraw = available;
  const offerSavings = phase === "broke" && available > 0 && !brokeBank;

  return (
    <div className="flex min-h-dvh flex-col px-5 pb-8 pt-8 sm:pt-10">
      {showEnding && (
        <div className="ending-screen">
          <p className="text-[11px] font-semibold tracking-[0.28em] uppercase opacity-70">
            Final achievement
          </p>
          <p className="mt-6 text-sm tracking-[0.2em] opacity-80">
            {formatMoney(FINAL_AMOUNT)}
          </p>
          <h1 className="ending-title">You Really Beat the Game Huh?</h1>
          <p className="mt-4 max-w-sm text-sm leading-relaxed opacity-70">
            There is nothing after this. You reached the last milestone.
          </p>
          <button
            className="btn btn-flip mt-12"
            onClick={() => setShowEnding(false)}
          >
            CONTINUE
          </button>
        </div>
      )}
      {toast && !showEnding && (
        <div className="achieve-toast">
          <div className="text-2xl">🏆</div>
          <p className="mt-1 text-[10px] font-semibold tracking-[0.22em] uppercase opacity-70">
            Milestone unlocked
          </p>
          <h2>{toast.name}</h2>
          <p>Reach {formatMoney(toast.amount)}.</p>
        </div>
      )}

      <header className="mx-auto w-full max-w-md text-center">
        <p className="text-lg font-extrabold tracking-wide sm:text-xl">
          🏆 HIGHEST SCORE: {formatMoney(globalHigh)}
        </p>
        <p className="mt-1 text-[11px] tracking-wide text-neutral-500">
          Highest score ever recorded
        </p>
        <p
          key={balanceKey}
          className="balance-pop mt-6 text-4xl font-extrabold tracking-tight sm:text-5xl"
        >
          💰 BALANCE: {formatMoney(balance)}
        </p>
        {debt > 0 && debtExpiresAt !== null && (
          <p className="mt-4 text-[15px] font-bold leading-relaxed tracking-[0.12em] text-red-800">
            🏦 BANK DEBT: {formatMoney(debt)}
            <br />
            TIME LEFT: {formatTime(timeLeft)}
          </p>
        )}
        {phase !== "pick" && phase !== "spin" && (
          <div className="mt-3 flex flex-wrap items-center justify-center gap-3">
            <button
              className="btn btn-text"
              onClick={() => {
                setShowMilestones((s) => !s);
                setShowSavings(false);
              }}
            >
              🏆 MILESTONES
            </button>
            {savingsUnlocked && (
              <button
                className="btn btn-text"
                onClick={() => {
                  setShowSavings((s) => !s);
                  setShowMilestones(false);
                  setWithdrawAmt(Math.min(1, available) || 1);
                }}
              >
                💰 SAVINGS
              </button>
            )}
          </div>
        )}
      </header>

      <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center">
        {!menuOpen && <Coin rotation={rotation} flipping={flipping} />}

        {showMilestones && (
          <div className="result-in mt-4 w-full text-center">
            <p className="text-xl font-extrabold tracking-[0.16em]">
              🏆 MILESTONES
            </p>
            <div className="mt-5 text-sm">
              <p className="text-[11px] font-semibold tracking-[0.16em] text-neutral-500">
                CURRENT
              </p>
              <p className="mt-1 font-bold">
                {current
                  ? `${formatMoney(current.amount)} — ${current.name}`
                  : "None yet"}
              </p>
              <p className="mt-4 text-[11px] font-semibold tracking-[0.16em] text-neutral-500">
                NEXT
              </p>
              <p className="mt-1 font-bold">
                {upcoming
                  ? `${formatMoney(upcoming.amount)} — ${upcoming.name}`
                  : "You really beat the game."}
              </p>
            </div>
            <div className="milestone-list mt-6">
              {MILESTONES.map((m) => {
                const got = unlocked.includes(m.amount);
                const extreme = m.amount >= EXTREME_FROM;
                const final = m.amount >= FINAL_AMOUNT;
                return (
                  <div
                    key={m.amount}
                    className={`milestone-row${got ? "" : " locked"}${
                      extreme ? " extreme" : ""
                    }${final ? " final" : ""}`}
                  >
                    <p>
                      {got ? "✓" : "○"} {formatMoney(m.amount)}
                    </p>
                    <p className={got ? "font-semibold" : ""}>
                      {got ? m.name : "???"}
                    </p>
                    {m.amount === EXTREME_FROM && (
                      <p className="mt-1 text-[10px] tracking-[0.14em] uppercase opacity-70">
                        Extreme milestones
                      </p>
                    )}
                    {final && (
                      <p className="mt-1 text-[10px] tracking-[0.14em] uppercase opacity-70">
                        Final
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
            <button
              className="btn btn-text mt-8"
              onClick={() => setShowMilestones(false)}
            >
              CLOSE
            </button>
          </div>
        )}

        {showSide && (
          <p className="mt-5 text-lg font-bold tracking-[0.28em] text-neutral-800">
            {outcome}
          </p>
        )}

        {showSavings && (
          <div className="result-in mt-4 w-full text-center">
            <p className="text-xl font-extrabold tracking-[0.16em]">💰 SAVINGS</p>
            <p className="mt-3 text-base font-semibold">
              AVAILABLE SAVINGS: {formatMoney(available)}
            </p>

            {settled.length > 0 && (
              <div className="savings-list mt-5">
                <p className="mb-1 text-xs font-semibold tracking-[0.16em] text-neutral-500">
                  ACTIVE DEPOSITS
                </p>
                {settled.map((d) => {
                  const ready = now >= d.readyAt;
                  const left = d.readyAt - now;
                  const val = ready
                    ? d.remaining ?? maturedReturn(d.principal)
                    : maturedReturn(d.principal);
                  return (
                    <div key={d.id} className="savings-row">
                      <p className="font-bold">
                        {formatMoney(d.principal)}
                        {ready ? ` → ${formatMoney(val)}` : ""}
                      </p>
                      {ready ? (
                        <p className="text-sm text-emerald-800">✓ READY</p>
                      ) : (
                        <p className="text-sm text-neutral-600">
                          ⏳ {formatTime(left)} remaining
                          <br />
                          <span className="text-xs">Locked until the timer finishes</span>
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {balance >= SAVE_MIN && (
              <div className="mt-6">
                <p className="text-xs font-semibold tracking-[0.16em] text-neutral-500">
                  DEPOSIT
                </p>
                <p className="mt-1 text-xs text-neutral-500">
                  Min {formatMoney(SAVE_MIN)} · Max {formatMoney(balance)}
                </p>
                <input
                  className="field mt-4"
                  inputMode="numeric"
                  value={depositInput}
                  onChange={(e) => {
                    const raw = e.target.value.replace(/\D/g, "");
                    if (raw === "") {
                      setDepositInput("");
                      return;
                    }
                    const n = Math.floor(Number(raw));
                    setDepositInput(String(Math.min(n, balance)));
                  }}
                />
                <div className="mt-3 flex items-center justify-center gap-2">
                  <button
                    className="btn btn-max"
                    onClick={() => setDepositInput(String(balance))}
                  >
                    MAX
                  </button>
                </div>
                <button
                  className="btn btn-flip mt-5"
                  disabled={!canDeposit}
                  onClick={() => depositSavings(depositAmt)}
                >
                  DEPOSIT {canDeposit ? formatMoney(depositAmt) : ""}
                </button>
              </div>
            )}
            {balance > 0 && balance < SAVE_MIN && (
              <p className="mt-6 text-xs text-neutral-500">
                Need at least {formatMoney(SAVE_MIN)} to deposit.
              </p>
            )}

            {available > 0 && (
              <div className="mt-7">
                <p className="text-sm font-semibold">
                  Withdraw: {formatMoney(Math.min(withdrawAmt, maxWithdraw))}
                </p>
                <div className="mt-3 flex items-center justify-center gap-2">
                  <button
                    className="btn btn-ghost"
                    disabled={withdrawAmt <= 1}
                    onClick={() => setWithdrawAmt((w) => Math.max(1, w - 1))}
                  >
                    −
                  </button>
                  <button
                    className="btn btn-ghost"
                    disabled={withdrawAmt >= maxWithdraw}
                    onClick={() =>
                      setWithdrawAmt((w) => Math.min(maxWithdraw, w + 1))
                    }
                  >
                    +
                  </button>
                  <button
                    className="btn btn-max"
                    onClick={() => setWithdrawAmt(maxWithdraw)}
                  >
                    MAX
                  </button>
                </div>
                <button
                  className="btn btn-flip mt-5"
                  onClick={() => withdrawSavings(withdrawAmt)}
                >
                  WITHDRAW
                </button>
              </div>
            )}

            {hasLocked && available === 0 && (
              <p className="mt-5 text-sm text-neutral-600">
                Locked savings can&apos;t be withdrawn yet.
              </p>
            )}

            <button
              className="btn btn-text mt-8"
              onClick={() => setShowSavings(false)}
            >
              CLOSE
            </button>
          </div>
        )}

        {!menuOpen && phase === "pick" && (
          <div className="mt-10 flex flex-col items-center">
            <p className="text-xl font-bold tracking-[0.18em]">HEADS OR TAILS?</p>
            <div className="mt-7 flex gap-3">
              <button className="btn btn-choice" onClick={() => pick("HEADS")}>
                HEADS
              </button>
              <button className="btn btn-choice" onClick={() => pick("TAILS")}>
                TAILS
              </button>
            </div>
          </div>
        )}

        {!menuOpen && phase === "result" && (
          <div className="result-in mt-8 text-center">
            <p className="text-2xl font-extrabold tracking-[0.16em]">
              {won ? "YOU WIN" : "YOU LOST"}
            </p>
            <p
              className={`mt-2 text-xl font-bold ${
                won ? "text-emerald-800" : "text-red-800"
              }`}
            >
              {won
                ? `${formatMoney(fromAmt)} → ${formatMoney(toAmt)}`
                : `-${formatMoney(Math.abs(delta))}`}
            </p>
            {repaid && (
              <p className="mt-5 text-sm font-bold tracking-[0.16em] text-emerald-800">
                BANK DEBT: $0
                <br />
                LOAN REPAID ✓
              </p>
            )}
            <button className="btn btn-flip mt-8" onClick={again}>
              FLIP AGAIN
            </button>
          </div>
        )}

        {!menuOpen && phase === "broke" && offerSavings && (
          <div className="mt-10 w-full text-center">
            <p className="text-xl font-extrabold tracking-[0.12em]">
              💰 YOU HAVE MONEY IN SAVINGS
            </p>
            <p className="mt-3 text-base tracking-wide">
              Withdraw some of your savings?
            </p>
            <button
              className="btn btn-flip mt-7"
              onClick={() => {
                setWithdrawAmt(Math.max(1, available));
                setShowSavings(true);
              }}
            >
              WITHDRAW
            </button>
            {hasLocked && (
              <p className="mt-4 text-sm text-neutral-600">
                Some deposits are still locked until their timers finish.
              </p>
            )}
            <button className="btn btn-text mt-6" onClick={() => setBrokeBank(true)}>
              BANK LOAN
            </button>
          </div>
        )}

        {!menuOpen && phase === "broke" && !offerSavings && (
          <div className="mt-10 w-full text-center">
            {hasLocked && (
              <p className="mb-6 text-sm text-neutral-600">
                Savings deposits are locked until their 5-minute timers finish.
              </p>
            )}
            <p className="text-xl font-extrabold tracking-[0.18em]">🏦 BANK</p>
            <p className="mt-3 text-base tracking-wide">
              You&apos;re out of points.
            </p>
            <div className="mt-6 flex flex-col items-center gap-2">
              {presets.map((n) => (
                <button
                  key={n}
                  className="btn btn-choice"
                  onClick={() => takeLoan(n)}
                >
                  BORROW {formatMoney(n)}
                </button>
              ))}
            </div>
          </div>
        )}

        {showFlip && (
          <button className="btn btn-flip mt-10" onClick={handleFlip}>
            FLIP
          </button>
        )}

        {showWager && (
          <div className="mt-10 text-center">
            <p className="text-base font-semibold tracking-wide">
              WAGER: {formatMoney(wager)}
            </p>
            <div className="mt-3 flex items-center justify-center gap-2">
              <button
                className="btn btn-ghost"
                disabled={wager <= 1}
                onClick={() => setWager((w) => clampWager(w - 1))}
              >
                −
              </button>
              <button
                className="btn btn-ghost"
                disabled={wager >= balance}
                onClick={() => setWager((w) => clampWager(w + 1))}
              >
                +
              </button>
              <button className="btn btn-max" onClick={() => setWager(balance)}>
                MAX
              </button>
            </div>
          </div>
        )}
      </main>

      <p className="pt-4 text-center text-[10px] tracking-wide text-neutral-400">
        Fictional in-game score. Not real money.
      </p>
    </div>
  );
}
